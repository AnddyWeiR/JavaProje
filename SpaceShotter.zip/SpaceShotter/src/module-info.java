/**
 * 
 */
/**
 * @author 90541
 *
 */
module UzayOyunu {
}