package background;

import java.util.Timer;
import java.util.TimerTask;

public class explosionClass {
	 Timer exp;
     private int periodH�z=50;
     private int temp=0;
     
     
	public explosionClass() {
		 exp=new Timer();	
		
		 exp.schedule(new TimerTask() {
			
			@Override
			public void run() {
				if(graphicsLibrary.explosionBoolean==true) {
					if(temp<10) {
						graphicsLibrary.explosionAnimation=temp;
						temp++;
					}
					else if(temp==10) {
						graphicsLibrary.explosionAnimation=10;
						temp=0;
						graphicsLibrary.explosionBoolean=false;
						
					}
				}
				
			}
		}, 0, periodH�z);
	}

}
