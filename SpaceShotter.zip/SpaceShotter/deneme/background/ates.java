package background;

public class ates {
	
	private int bulletX;
	private int bulletY;
	public ates(int bulletX, int bulletY) {
		super();
		this.bulletX = bulletX;
		this.bulletY = bulletY;
	}
	public int getBulletX() {
		return bulletX;
	}
	public void setBulletX(int bulletX) {
		this.bulletX = bulletX;
	}
	public int getBulletY() {
		return bulletY;
	}
	public void setBulletY(int bulletY) {
		this.bulletY = bulletY;
	}
	

}
