package background;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class graphicsLibrary extends JPanel{
	
	BufferedImage resim1;
	BufferedImage resim2;
	BufferedImage rocketImage;
	BufferedImage tasImage;
	BufferedImage explosionArray[]= new BufferedImage[16];
	BufferedImage presentImage;
	BufferedImage atesImage;
	
	static ArrayList<ates> atesler= new ArrayList<ates>();
	
	
	static int backgroundY1=0;
	static int backgroundY2=500;
	static int backgroundSpeed=15;
	static int rocketX=250;
	static int rocketY=250;
	static int explosionAnimation;

	static int tasH�zlanma[]= new int[6];
	static int tasX[]=new int[6];
	static int tasY[]=new int[6];
	static int presentX[]=new int[6];
	static int presentY[]=new int[6];
	static int presentH�z[]=new int[6];
	static int live=100;
	static int liveValue=10;
	static int liveValue1=20;
	static int harcanan_ates=0;
	static int azalanY=4;
	
	
	static boolean moveup=false,movedown=false,moveleft=false,moveright=false;
	static boolean explosionBoolean=false;
	static boolean liveBoolean=false;
	
	
	public graphicsLibrary()  {
		
		setFocusable(true);
		
		try{
		resim1= ImageIO.read(new File("rsc/bg2.png"));
		resim2= ImageIO.read(new File("rsc/bg2.png"));
		rocketImage=ImageIO.read(new File("rsc/rockett.png"));
		tasImage=ImageIO.read(new File("rsc/asteroid.png"));
		presentImage=ImageIO.read(new File("rsc/�d�l.png"));
		atesImage=ImageIO.read(new File("rsc/fire.png"));
		
		
		
		
		for(int i=0;i<=10;i++) {
			explosionArray[i]=ImageIO.read(new File("rsc/fire"+(i+1)+".png"));
		}
		
		}
		
	 catch(IOException e) {
		 e.printStackTrace();
	 }
	}
	
	
public void paint(Graphics g) { 
	super.paint(g);
	
	g.drawImage(resim1,0,backgroundY1,600,500,null);  //y eksenini kontrol edebilmek için böyle yaptık
	g.drawImage(resim2,0,backgroundY2,600,500,null);
	g.drawImage(rocketImage,rocketX,rocketY,100,90, null);
	
	
	//BULLET
	
	for(ates ates : atesler) {
		
		try {
			g.drawImage(atesImage, ates.getBulletX(), ates.getBulletY(), 120, 70,null);
			
			
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	//TA�
	for(int i=0;i<=5;i++)
	{
	g.drawImage(tasImage,tasX[i],tasY[i],30,60,null);
	}
	//�D�L
	for(int i=0;i<=5;i++) {
		g.drawImage(presentImage,presentX[i],presentY[i],30,30,null);
	}
	
	if(graphicsLibrary.explosionBoolean==true) //ta� rokete �arpt�
		{
		for(int i=0;i<10;i++) {
			if(explosionAnimation==i) {
				 g.drawImage(explosionArray[i],rocketX,rocketY-20,73,100,null);
			}
		
	 }
		if(explosionAnimation>0&& explosionAnimation<6) {
			g.setColor(new Color(230,0,0,65));
			g.fillRect(0,0,getWidth(),getHeight());
		}
		else if(explosionAnimation>6 && explosionAnimation<15) {
			g.setColor(new Color(230,0,0,65));
			g.fillRect(0,0,getWidth(),getHeight());
		}
		
		//sa�l�k
		g.setColor(Color.CYAN);
		g.setFont(new Font("Arial",Font.BOLD,20));
		g.drawString("Live :"+graphicsLibrary.live,5,30);
	}
	
	repaint();
	
	
	
	
}
}