package background;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;

public class rocketMovement extends JPanel implements KeyListener{

	public rocketMovement() {
		setFocusable(true);
		addKeyListener(this);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		
		
	}

	@Override
	public void keyPressed(KeyEvent e) { //klavyeye bas�ld���� zaman i�lenecek kodlar
		
	if(e.getKeyCode()==KeyEvent.VK_W) {//false olan de�eri w ye bas�ld��� zaman true yapar ve uzay gemisini hareket ettirir (yukar�)
		graphicsLibrary.moveup = true;	
	 }
	
	else if(e.getKeyCode()==KeyEvent.VK_S) {
		graphicsLibrary.movedown = true;	
	 }
	
	else if(e.getKeyCode()==KeyEvent.VK_A) {
		graphicsLibrary.moveleft = true;	
	 }
	else if(e.getKeyCode()==KeyEvent.VK_D) {
		graphicsLibrary.moveright = true;	
	   }
	
	if(e.getKeyCode()== KeyEvent.VK_SPACE) {
		graphicsLibrary.atesler.add(new ates(graphicsLibrary.rocketX,graphicsLibrary.rocketY));
	    graphicsLibrary.harcanan_ates++;
		
		
	}
	
	
	
	
	}

	@Override
	public void keyReleased(KeyEvent e) {
	
		if(e.getKeyCode()==KeyEvent.VK_W) {//false olan de�eri w ye bas�ld��� zaman true yapar ve uzay gemisini hareket ettirir (yukar�)
			graphicsLibrary.moveup = false;	
		 }
		
		else if(e.getKeyCode()==KeyEvent.VK_S) {
			graphicsLibrary.movedown = false;	
		 }
		
		else if(e.getKeyCode()==KeyEvent.VK_A) {
			graphicsLibrary.moveleft = false;	
		 }
		else if(e.getKeyCode()==KeyEvent.VK_D) {
			graphicsLibrary.moveright = false;	
		 }
		
	
		
	}
		
		
		
		
		
		
	}


