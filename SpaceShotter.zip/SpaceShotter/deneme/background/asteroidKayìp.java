package background;

import java.util.Timer;
import java.util.TimerTask;

public class asteroidKay�p {
	Timer tas1;
	private int periodH�z=15;
	private int temp=0;

	public asteroidKay�p() {
		
		tas1= new Timer();
		tas1.scheduleAtFixedRate(new TimerTask() {
			
			@Override
			public void run() {
				
				for(int i=0;i<=5;i++) {  //rokete �arpan asteroidin yok olmas� i�in (asl�nda yok olmuyuor onun koordinatlar�n� yukar� at�yoruz
					if(temp==0) {
						
						if(graphicsLibrary.rocketX>=graphicsLibrary.tasX[i]-40 && graphicsLibrary.rocketX<=graphicsLibrary.tasX[i]+40 &&
								graphicsLibrary.rocketY>=graphicsLibrary.tasY[i] && graphicsLibrary.rocketY<=graphicsLibrary.tasY[i]+50){
							
							graphicsLibrary.tasY[i]=-100;
							graphicsLibrary.explosionBoolean=true;
							
							if(graphicsLibrary.explosionBoolean==true) {
								graphicsLibrary.live-=10+graphicsLibrary.liveValue1;					}
							
						}
					
					}
					
					
				}
				
			}
		}, 0,periodH�z);
				
		
	}

}
