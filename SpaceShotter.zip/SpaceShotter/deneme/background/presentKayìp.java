package background;

import java.util.Timer;
import java.util.TimerTask;

public class presentKay�p {

	 Timer timer;
	 private int temp=0;
	 private int periodH�z=20;
	 
	 
	public presentKay�p() {
		
		timer =new Timer();
		timer.schedule(new TimerTask() {
			
			@Override
			public void run() {
				
	for(int i=0;i<5;i++) {
		
		if(graphicsLibrary.rocketX>=graphicsLibrary.presentX[i]-65 && graphicsLibrary.rocketX<=graphicsLibrary.presentX[i]+30 &&
				
						graphicsLibrary.rocketY>=graphicsLibrary.presentY[i]-30 && graphicsLibrary.rocketY<=graphicsLibrary.presentY[i]+65){
					graphicsLibrary.liveBoolean=true; //roket �d�le �arpt�,true yapt�
					graphicsLibrary.presentY[i]=-100;
					
					if(graphicsLibrary.liveBoolean==true) {
						graphicsLibrary.live+=graphicsLibrary.liveValue;
					}
				
					}
				}
			}
				
			
		}, 0, periodH�z);

	}
}
