package background;

import javax.swing.JFrame;
import javax.swing.JOptionPane;



public class Main {
	
static int setWidth = 600;
static int setHeight = 500;


	public static void main(String[] args) {
		
		
		JFrame frame= new JFrame();
		JFrame f= new JFrame();
		//JOptionPane.showMessageDialog(f, "YANDINIZ", "Space Shotter", JOptionPane.WARNING_MESSAGE);
		graphicsLibrary graphicsLib= new graphicsLibrary();
		rocketSpeed rocktsp = new rocketSpeed();
		tasCogaltma tascogalt =new tasCogaltma();
		presentClass present= new presentClass();
		presentKay�p present2= new presentKay�p();
		asteroidKay�p asteroidkay�p= new asteroidKay�p();
		bulletTimer bull = new bulletTimer();
		explosionClass exp= new explosionClass();	
		rocketMovement rocketm= new rocketMovement();		
		frame.add(rocketm);
		frame.add(graphicsLib);
		frame.setTitle("Space Adventure");
		frame.setSize(setWidth,setHeight);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		
		
		
		
	}

}
