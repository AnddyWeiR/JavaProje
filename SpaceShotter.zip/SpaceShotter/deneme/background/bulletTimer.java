package background;

import java.util.Timer;
import java.util.TimerTask;

public class bulletTimer {
Timer timer;

public bulletTimer() {
	
	timer=new Timer();
	
	timer.scheduleAtFixedRate(new TimerTask() {
		
		@Override
		public void run() {
			
			try {
			
			for(ates ates : graphicsLibrary.atesler) {
				ates.setBulletY(ates.getBulletY()-graphicsLibrary.azalanY);
				
				if(ates.getBulletY()<0) {
					graphicsLibrary.atesler.remove(ates);
					graphicsLibrary.harcanan_ates--;
					
				}
			}
		}
			catch(Exception e) {
				e.printStackTrace();			
				}
			
	}
	}, 0, 15);
	
	
   }

}
