package background;

import java.util.Timer;
import java.util.TimerTask;

public class presentClass {
	
	private int temp=0;
	Timer timer;
	private int periodH�z=20;
	

	

	public presentClass() {
		
		for(int i=0;i<=5;i++) {
			graphicsLibrary.presentX[i]+= 10+temp; //�d�l sa�a do�ru artacak
			graphicsLibrary.presentY[i]-=-100+temp;
			temp+=100;
		}
		timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask() {
			
			@Override
			public void run() { //�D�LLER�N HIZLARI �� �E��T �D�L OLACAK 
				graphicsLibrary.presentH�z[0]=3;
				graphicsLibrary.presentH�z[1]=7;
				graphicsLibrary.presentH�z[2]=4;
				graphicsLibrary.presentH�z[3]=6;
				graphicsLibrary.presentH�z[4]=2;
				graphicsLibrary.presentH�z[5]=5;
			
				for(int i=0;i<=5;i++) {
					graphicsLibrary.presentY[i]+= graphicsLibrary.presentH�z[i];
					if(graphicsLibrary.presentY[i] >=Main.setHeight) {
						
						graphicsLibrary.presentY[i]=-100;
						
					}
				
				}
				
			}
		},0,periodH�z);//periodH�z
		
	}

}
