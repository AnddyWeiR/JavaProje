package background;



import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class FinishPanel {

	public static void main(String[] args) {
		

	// if(live.graphicsLibrary==0) {
 JFrame f= new JFrame();
 JOptionPane.showConfirmDialog(f, "YANDINIZ, tekrar oynamak ister misiniz?", "Space Shotter", JOptionPane.YES_NO_OPTION);

 
	}
}
